﻿using static StupidTemplate.Menu.Main;
using static StupidTemplate.Settings;

namespace StupidTemplate.categorie_things
{
    internal class Categorys
    {
        public static void Movement()
        {
            buttonsType = 5;
        }

        public static void Visual()
        {
            buttonsType = 6;
        }

        public static void Rig()
        {
            buttonsType = 7;
        }
        public static void Safety()
        {
            buttonsType = 8;
        }
        public static void Projectile()
        {
            buttonsType = 9;
        }

        public static void Fun()
        {
            buttonsType = 10;
        }

        public static void Overpowered()
        {
            buttonsType = 11;
        }

    }
}
